package cl.mbascunan.icloset

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()